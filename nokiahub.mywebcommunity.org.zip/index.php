<?php ?>
<!DOCTYPE html>
<html>
<head>
  <title>Nokia Hub</title>
</head>
<body>

<h2>NOKIA HUB</h2>

<p>Select a tool:</p>

<ul>
  <li><a href="calculator.php">Calculator</a></li>
  <li><a href="txt_grabber.php">TXT Grabber</a></li>
  <li><a href="https://nokia-ai-backend.onrender.com/ai">Nokia AI</a></li>
        <li><a href="https://ai-backend-2-ycfw.onrender.com/ai">Nokia AI 2</a></li>
</ul>

<p>All tools designed for Nokia phones.</p>
<br>
<h6>Made by aydin.</h6>

</body>
</html>
